# Author: Sankalp Khare. 
# Email: sankalpkhare@gmail.com
# Edited by JohnDoe 

import re,os
import urllib2,datetime
import DCHub,time

class TVInfo(DCHub.DCHubBot):
    def __init__(self,hub,nick = 'TVInfo'):
        nick = 'TVInfo'
        DCHub.DCHubBot.__init__(self, hub, nick)
        self.usage = """
Get information about a TV Show (or a particular episode) right from your DC++ Client!
Usage:
!tvinfo (this just prints the usage instructions)
showName                  #Example: mentalist
showName -e EpisodeNumber #Example: collar -e 1x12
    """
        self.tvinfo('mentalist')
    def getTVrageURL(self,show,episode,exact):
        URL = "http://services.tvrage.com/tools/quickinfo.php?"
        show = show.replace(" ","%20")
        URL+=("show="+show)
        if episode:
            URL+=("&ep="+episode)
        else:
            URL+=('&ep=""')
        if exact:
            URL+=("&exact=1")
        else:
            URL+=("&exact=0")
        return URL
    
    def makeDict(self,info):
        info = info.splitlines()
        dict = {}
        for line in info:
            line = line.split('@')
            dict[line[0]] = line[1]
        return dict
    
    def dtObj(self,ts):
        splitRegEx = re.compile('(\d+-\d+-\d+T\d+:\d+:\d+)(.*)')
        matchObject = splitRegEx.match(ts)
        UTCtimestr = matchObject.group(1)
        d = datetime.datetime.strptime(UTCtimestr,"%Y-%m-%dT%H:%M:%S")
        offset = matchObject.group(2)
        offsetSplitRegEx = re.compile('([+-])(\d+):(\d+)')
        offsetMatchObject = offsetSplitRegEx.match(offset)
        offsetHours = int(offsetMatchObject.group(2))
        offsetMinutes = int(offsetMatchObject.group(3))
        if offsetMatchObject.group(1) == "-":
            offsetHours*=-1
            offsetMinutes*=-1
        td = datetime.timedelta(hours=offsetHours,minutes=offsetMinutes)
        UTCAirTime = d - td
        return UTCAirTime
    
    def stripMilliSeconds(self,deltastr):
        stripRegEx = re.compile('(.*)\..*')
        matchObject = stripRegEx.match(deltastr)
        return matchObject.group(1)
    
    def printInfo(self,dict):
        searchResult = "\r\n"
        if dict.has_key("Episode Info"):
            width = len(dict["Show Name"])+len(dict["Episode Info"])+13
            epInfo = dict["Episode Info"].split('^')
            searchResult += dict["Show Name"]+" "+epInfo[0]+" "+epInfo[1]+", Aired on "+epInfo[2]+ "\r\n"
            searchResult += dict["Episode URL"] + "\r\n"
            searchResult += "+ Country          : %s" % (dict["Country"]) + "\r\n"
            searchResult += "+ Network          : %s" % (dict["Network"]) + "\r\n"
            if dict.has_key("Airtime"):
                searchResult += "+ Airing time      : %s" % (dict["Airtime"]) + "\r\n"
            searchResult += "+ Runtime (min)    : %s" % (dict["Runtime"]) + "\r\n"
        else:
            width = len(dict["Show Name"])+len(dict["Premiered"])+17
            searchResult += dict["Show Name"]+", Premiered in "+dict["Premiered"]+ "\r\n"
            searchResult += dict["Show URL"] + "\r\n"
            searchResult += "+ Started on       : %s" % (dict["Started"]) + "\r\n"
            searchResult += "+ Status           : %s" % (dict["Status"]) + "\r\n"
            if dict["Ended"]:
                searchResult += "+ Ended on         : %s" % (dict["Ended"]) + "\r\n"
            searchResult += "+ Country          : %s" % (dict["Country"]) + "\r\n"
            searchResult += "+ Network          : %s" % (dict["Network"]) + "\r\n"
            if dict.has_key("Airtime"):
                searchResult += "+ Airing time      : %s" % (dict["Airtime"]) + "\r\n"
            searchResult += "+ Classification   : %s" % (dict["Classification"]) + "\r\n"
            searchResult += "+ Genre(s)         : %s" % (dict["Genres"]) + "\r\n"
            searchResult += "+ Runtime (min)    : %s" % (dict["Runtime"]) + "\r\n"
            if dict.has_key("Latest Episode"):
                latestEpInfo = dict["Latest Episode"].split('^')
                searchResult += "+ Latest episode   : %s %s, Aired on %s" % (latestEpInfo[0],latestEpInfo[1],latestEpInfo[2]) + "\r\n"
            if dict.has_key("Next Episode"):
                nextEpInfo = dict["Next Episode"].split('^')
                searchResult += "+ Upcoming Episode : %s %s, Airing on %s" % (nextEpInfo[0],nextEpInfo[1],nextEpInfo[2]) + "\r\n"
            try:
                utcairtime = self.dtObj(dict["RFC3339"])
                runtimeDelta = datetime.timedelta(minutes=int(dict["Runtime"]))
                utcendtime = utcairtime + runtimeDelta
                timenow = datetime.datetime.utcnow()
                if timenow > utcairtime:
                    tta = timenow - utcairtime
                    searchResult += "+ Next Ep Aired    :"
                    searchResult += self.stripMilliSeconds(str(tta))
                    searchResult += "ago" + "\r\n"
                else:
                    tta = utcairtime - timenow
                    searchResult += "+ Next Ep Airs in  :"
                    searchResult += self.stripMilliSeconds(str(tta))+ "\r\n"
                if timenow > utcendtime:
                    tte = timenow - utcendtime
                    searchResult += "+ Next Ep Ended    :"
                    searchResult += self.stripMilliSeconds(str(tte))
                    searchResult += "ago" + "\r\n"
                else:
                    tte = utcendtime - timenow
                    searchResult += "+ Next Ep Ends in  :"
                    searchResult += self.stripMilliSeconds(str(tte)) + "\r\n"
            except KeyError:
                searchResult += "+ Next Ep Airs in  : Info Unavailable" + "\r\n"
        return searchResult
    def tvinfo(self,message=0): 
        if not message:
            return self.usage
        messageParts = message.split('-e')
        if len(messageParts)==1:
            show = messageParts[0].strip()
            episode = ''
        elif len(messageParts)==2:
            show = messageParts[0].strip()
            episode = messageParts[1].strip()
        else: return self.usage
        # URL in which the values will be substituted
        URL = self.getTVrageURL(show,episode,'')
        proxy = urllib2.ProxyHandler({'http': 'http://proxy.iiit.ac.in:8080'})
        opener = urllib2.build_opener(proxy)
        urllib2.install_opener(opener)
        f = urllib2.urlopen(URL)
        info = f.read()
        info = info.split("<pre>")
        
        try:
            resultDict = self.makeDict(info[1])
            result = self.printInfo(resultDict)
            result = result.replace('|','+') +"|"
            return result
        except:
            return "%s : Unable to find show by this name\nPerhaps being more precise will help...\n"%message 
