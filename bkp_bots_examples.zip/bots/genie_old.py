# Author: JohnDoe
import os,sys
import DCHub,time

class genie(DCHub.DCHubBot):
	def __init__(self,hub,nick = 'Genie'):
		nick = 'Genie'
		DCHub.DCHubBot.__init__(self, hub, nick)
		self.Board = open('board').read()
		self.Requests = open('requests').read()
		self.Dwds = open('dwds').read()
		self.genie = ['add','read','addreq','req','help','adddwd','dwd']
		self.availableCommands = '''
----------------------------------------------------------------
Available Commands are: +add +read +addreq +req +help !tvinfo.
Usage:
+add Description : adds stuff to the read board.
+read : displays the read board.
+addreq Description : adds stuff to the request board.
+req : displays the request board.
!tvinfo : helps you interact with the TVinfo Bot. Get info about TV shows!
+dwd : (For Downloaders.) displays the downloaders' board. (List of what everyone else is downloading.)
+adddwd: (For Downloaders.) adds stuff to the downloaders board.
----------------------------------------------------------------
		'''
	def help(self,user,message):
		try:
			user.sendmessage('<Hub-Genie> %s |'%self.availableCommands)
			self.hub.give_PrivateMessage(self,user,self.availableCommands)
			return "Success"
		except Exception,e:
			return "Failure"
	def read(self,user,message):
		try:
			self.hub.give_PrivateMessage(self,user,'Read-Board:\r\n'+self.Board)
			return "Success" 
		except Exception,e:
			return "Read Error!"
	def req(self,user,message):
		try:
			self.hub.give_PrivateMessage(self,user,'Request-Board:\r\n'+self.Requests)
			return "Success" 
		except Exception,e:
			return "Read Error!"
	def add(self,user,message):
		if len(message)<4:
			return "Too Short!"
		try:
			self.Board = self.Board + time.ctime()+"] <"+ user.nick +"> : "+message
			taskStat = self.dumpToBoard()
			self.read(user,message)
			return taskStat
		except Exception,e:
			return "Write Error!"
	def adddwd(self, user, message):
		if len(message) < 4:
			return "Too Short!"
		try:
			self.Dwds = self.Dwds + time.ctime()+"] <"+ user.nick +"> : "+message
			taskStat = self.dumpToDwds()
			self.dwd(user,message)
			return taskStat
		except Exception,e:
			return "Write Error!"
	def dwd(self, user, message):
		try:
			self.hub.give_PrivateMessage(self,user,'Downloaders\'-board:\r\n'+self.Dwds)
			return "Success" 
		except Exception,e:
			return "Read Error!"
	def addreq(self,user,message):
		if len(message)<4:
			return "Too Short!"
		try:
			self.Requests = self.Requests + time.ctime()+"] <" + user.nick +"> : "+message
			taskStat=self.dumpToRequests()
			self.req(user,message)
			return taskStat
		except Exception,e:
			return "Write Error!"
	def dumpToBoard(self):
		try:
			myFile = open('board.tmp','w')
			myFile.write(self.Board)
			myFile.close()
			os.rename('board.tmp','board')
			return "Successfully wrote to board."
		except Exception,e:
			print e
			return "Write Error!"
	def dumpToRequests(self):
		try:
			myFile = open('requests.tmp','w')
			myFile.write(self.Requests)
			myFile.close()
			os.rename('requests.tmp','requests')
			return "Successfully wrote to requests."
		except Exception,e:
			return "Write Error!"
	def dumpToDwds(self):
		try:
			myFile = open('dwds.tmp','w')
			myFile.write(self.Dwds)
			myFile.close()
			os.rename('dwds.tmp','dwds')
			return "Successfully wrote to dwds."
		except Exception,e:
			return "Write Error!"
