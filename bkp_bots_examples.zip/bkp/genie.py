# Author: JohnDoe
import os,sys
import DCHub,time

class genie(DCHub.DCHubBot):
	def __init__(self,hub,nick = 'Genie'):
		nick = 'Genie'
		DCHub.DCHubBot.__init__(self, hub, nick)
		self.Board = open('board').read()
		self.Requests = open('requests').read()
		self.genie = ['add','read','addreq','req','help']
		self.availableCommands = 'Available Commands are: '+' '.join(map(lambda comm:'+'+comm,self.genie))

	def help(self,user,message):
		try:
			user.sendmessage('<Hub-Genie> %s |'%self.availableCommands)
			return "Success"
		except:
			return "Failure"
	def read(self,user,message):
		try:
			self.hub.give_PrivateMessage(self,user,'Read-Board:\r\n'+self.Board)
			return "Success" 
		except:
			return "Read Error!"
	def req(self,user,message):
		try:
			self.hub.give_PrivateMessage(self,user,'Request-Board:\r\n'+self.Requests)
			return "Success" 
		except:
			return "Read Error!"
	def add(self,user,message):
		try:
			self.Board = self.Board + time.ctime()+"] <"+ user.nick +"> : "+message
			return self.dumpToBoard()
		except:
			return "Write Error!"
	def addreq(self,user,message):
		try:
			self.Requests = self.Requests + time.ctime()+"] <" + user.nick +"> : "+message
			return self.dumpToRequests()
		except:
			return "Write Error!"
	def dumpToBoard(self):
		try:
			myFile = open('board.tmp','w')
			myFile.write(self.Board)
			myFile.close()
			os.rename('board.tmp','board')
			return "Successfully wrote to board."
		except:
			return "Write Error!"
	def dumpToRequests(self):
		try:
			myFile = open('requests.tmp','w')
			myFile.write(self.Requests)
			myFile.close()
			os.rename('requests.tmp','requests')
			return "Successfully wrote to requests."
		except:
			return "Write Error!"
